// ============================================
// CORE.JS – UmbraShield Shared Utilities
// Solana Devnet · Real transactions
// ============================================

const Core = {
  wallet: null,           // { publicKey, provider }
  connection: null,       // solanaWeb3.Connection
  network: 'devnet',
};

// ── Solana Connection (Devnet) ──────────────
function getSolanaConnection() {
  if (!Core.connection) {
    Core.connection = new solanaWeb3.Connection(
      solanaWeb3.clusterApiUrl('devnet'),
      'confirmed'
    );
  }
  return Core.connection;
}

// ── Session Persistence ─────────────────────
function saveWalletSession(publicKey, walletType) {
  sessionStorage.setItem('umbra_session', JSON.stringify({ publicKey, walletType }));
}
function loadWalletSession() {
  try { return JSON.parse(sessionStorage.getItem('umbra_session')); } catch { return null; }
}
function clearWalletSession() {
  sessionStorage.removeItem('umbra_session');
}

// ── Wallet Connect: Phantom ─────────────────
async function connectPhantom(redirectAfter = true) {
  const provider = window.solana || window.phantom?.solana;

  if (!provider || !provider.isPhantom) {
    toast('Phantom not found. Please install it.', 'error');
    setTimeout(() => window.open('https://phantom.app', '_blank'), 1500);
    return false;
  }

  try {
    toast('Connecting to Phantom...', 'info');
    const resp = await provider.connect();
    const publicKey = resp.publicKey.toString();

    Core.wallet = { publicKey, provider };
    saveWalletSession(publicKey, 'phantom');

    toast('Wallet connected!', 'success');
    closeModal('walletModal');

    if (redirectAfter) {
      setTimeout(() => { window.location.href = _dashUrl(); }, 900);
    }
    return true;
  } catch (err) {
    toast('Connection cancelled: ' + err.message, 'error');
    return false;
  }
}

// ── Disconnect ──────────────────────────────
function disconnectWallet() {
  clearWalletSession();
  Core.wallet = null;
  window.location.href = _rootUrl() + 'index.html';
}

// ── Balance ─────────────────────────────────
async function fetchBalance(publicKey) {
  try {
    const conn = getSolanaConnection();
    const pk = new solanaWeb3.PublicKey(publicKey);
    const lamports = await conn.getBalance(pk);
    return lamports / solanaWeb3.LAMPORTS_PER_SOL;
  } catch { return 0; }
}

// ── Airdrop (Devnet) ─────────────────────────
async function requestDevnetAirdrop(publicKey, amountSol = 2) {
  try {
    const conn = getSolanaConnection();
    const pk = new solanaWeb3.PublicKey(publicKey);
    toast('Requesting devnet airdrop...', 'info');
    const sig = await conn.requestAirdrop(pk, amountSol * solanaWeb3.LAMPORTS_PER_SOL);
    await conn.confirmTransaction(sig, 'confirmed');
    toast(`${amountSol} SOL airdropped!`, 'success');
    return sig;
  } catch (err) {
    toast('Airdrop failed: ' + err.message, 'error');
    return null;
  }
}

// ── Real SOL Transfer (Devnet) ───────────────
// Sends actual SOL from donor to streamer wallet on devnet
async function sendSolTransfer(fromProvider, fromPublicKey, toPublicKey, amountSol) {
  const conn = getSolanaConnection();
  const from = new solanaWeb3.PublicKey(fromPublicKey);
  const to   = new solanaWeb3.PublicKey(toPublicKey);
  const lamports = Math.round(amountSol * solanaWeb3.LAMPORTS_PER_SOL);

  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash('confirmed');

  const tx = new solanaWeb3.Transaction({
    recentBlockhash: blockhash,
    feePayer: from,
  }).add(
    solanaWeb3.SystemProgram.transfer({ fromPubkey: from, toPubkey: to, lamports })
  );

  // Sign with Phantom
  const signed = await fromProvider.signTransaction(tx);
  const sig = await conn.sendRawTransaction(signed.serialize());
  await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, 'confirmed');
  return sig;
}

// ── Umbra SDK init (devnet) ──────────────────
// Returns a real UmbraClient for confidential ops
async function initUmbraClient(walletProvider, publicKey) {
  try {
    // UmbraSDK is the bundled window global from umbra-sdk.js
    if (typeof UmbraSDK === 'undefined' || !UmbraSDK.getUmbraClient) {
      console.warn('UmbraSDK not loaded, using simulation mode');
      return null;
    }

    const signer = {
      publicKey,
      signTransaction: async (tx) => await walletProvider.signTransaction(tx),
      signMessage: async (msg) => await walletProvider.signMessage(msg),
      signTransactions: async (txs) => {
        const out = [];
        for (const tx of txs) out.push(await walletProvider.signTransaction(tx));
        return out;
      }
    };

    const client = await UmbraSDK.getUmbraClient({
      signer,
      network: 'devnet',
      rpcUrl: 'https://api.devnet.solana.com',
      rpcSubscriptionsUrl: 'wss://api.devnet.solana.com',
      indexerApiEndpoint: 'https://utxo-indexer.devnet.umbraprivacy.com',
      deferMasterSeedSignature: false,
    });

    return client;
  } catch (err) {
    console.warn('Umbra client init failed:', err.message);
    return null;
  }
}

// ── Profile helpers ──────────────────────────
function saveProfile(publicKey, data) {
  localStorage.setItem(`umbra_profile_${publicKey}`, JSON.stringify(data));
}
function loadProfile(publicKey) {
  try { return JSON.parse(localStorage.getItem(`umbra_profile_${publicKey}`)); } catch { return null; }
}
function saveDonationLink(data) {
  // By wallet address
  localStorage.setItem(`umbra_link_${data.walletAddress}`, JSON.stringify(data));
  // By username (for lookup from donate page)
  localStorage.setItem(`umbra_user_${data.username.toLowerCase()}`, JSON.stringify(data));
}
function loadDonationLinkByWallet(walletAddress) {
  try { return JSON.parse(localStorage.getItem(`umbra_link_${walletAddress}`)); } catch { return null; }
}
function loadDonationLinkByUsername(username) {
  try { return JSON.parse(localStorage.getItem(`umbra_user_${username.toLowerCase()}`)); } catch { return null; }
}
function saveDonationRecord(streamerWallet, record) {
  const key = `umbra_donations_${streamerWallet}`;
  const list = loadDonationHistory(streamerWallet);
  list.unshift(record);
  localStorage.setItem(key, JSON.stringify(list.slice(0, 100)));
}
function loadDonationHistory(streamerWallet) {
  try { return JSON.parse(localStorage.getItem(`umbra_donations_${streamerWallet}`)) || []; } catch { return []; }
}

// ── URL helpers ──────────────────────────────
function _rootUrl() {
  const p = window.location.pathname;
  const idx = p.indexOf('/dashboard/');
  if (idx >= 0) return p.slice(0, idx) + '/';
  const idx2 = p.lastIndexOf('/');
  return p.slice(0, idx2 + 1);
}
function _dashUrl() { return _rootUrl() + 'dashboard/index.html'; }

// ── Toast ────────────────────────────────────
function toast(msg, type = 'info') {
  const icons = { success: 'fa-check-circle', error: 'fa-times-circle', info: 'fa-info-circle' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="fas ${icons[type]} toast-icon"></i><span>${msg}</span>`;
  const container = document.getElementById('toasts');
  if (!container) return;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity='0'; el.style.transition='opacity 0.3s'; setTimeout(() => el.remove(), 300); }, 4000);
}

// ── Modal ────────────────────────────────────
function openModal(id) {
  document.getElementById(id)?.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
  document.body.style.overflow = '';
}
function openWalletModal() { openModal('walletModal'); }

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-bg.open').forEach(m => {
      m.classList.remove('open');
      document.body.style.overflow = '';
    });
  }
});

// Click-outside to close modals
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-bg')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// ── TX Modal helpers ─────────────────────────
function showTxModal(title) {
  document.getElementById('txTitle').textContent = title;
  document.getElementById('txBody').innerHTML = `
    <div class="tx-steps" id="txSteps">
      <div class="tx-step" id="ts1"><i class="fas fa-signature step-icon"></i><div class="step-text"><b>Sign Transaction</b><span>Approve in your wallet</span></div></div>
      <div class="tx-step" id="ts2"><i class="fas fa-shield-halved step-icon"></i><div class="step-text"><b>Privacy Shield</b><span>Umbra ZK proof on Devnet</span></div></div>
      <div class="tx-step" id="ts3"><i class="fas fa-paper-plane step-icon"></i><div class="step-text"><b>Submit to Devnet</b><span>Broadcasting transaction</span></div></div>
      <div class="tx-step" id="ts4"><i class="fas fa-check step-icon"></i><div class="step-text"><b>Confirmed</b><span>Transaction finalized</span></div></div>
    </div>`;
  openModal('txModal');
}

function setTxStep(n) {
  for (let i = 1; i <= 4; i++) {
    const el = document.getElementById('ts' + i);
    if (!el) continue;
    el.classList.remove('active', 'done');
    if (i < n) el.classList.add('done');
    else if (i === n) el.classList.add('active');
  }
}

function showTxSuccess(sig, message) {
  const explorerUrl = `https://explorer.solana.com/tx/${sig}?cluster=devnet`;
  document.getElementById('txBody').innerHTML = `
    <div class="tx-success">
      <div class="icon-ok"><i class="fas fa-check-circle"></i></div>
      <h3>Transaction Confirmed!</h3>
      <p>${message || 'Your transaction was successfully submitted to Solana Devnet.'}</p>
      <div class="sig-box">${sig}</div>
      <a class="explorer-link" href="${explorerUrl}" target="_blank">
        <i class="fas fa-external-link-alt"></i> View on Solana Explorer (Devnet)
      </a>
    </div>`;
}

function showTxError(msg) {
  document.getElementById('txBody').innerHTML = `
    <div class="tx-success">
      <div class="icon-ok" style="color:var(--red)"><i class="fas fa-times-circle"></i></div>
      <h3>Transaction Failed</h3>
      <p>${msg}</p>
    </div>`;
}

function closeTx() {
  closeModal('txModal');
}

// ── Format ───────────────────────────────────
function shortAddr(addr) {
  if (!addr) return '';
  return addr.slice(0, 5) + '...' + addr.slice(-4);
}
function formatSol(n) { return parseFloat(n).toFixed(4); }
function timeAgo(iso) {
  const d = Date.now() - new Date(iso).getTime();
  if (d < 60000) return 'just now';
  if (d < 3600000) return Math.floor(d/60000) + 'm ago';
  if (d < 86400000) return Math.floor(d/3600000) + 'h ago';
  return new Date(iso).toLocaleDateString();
}
