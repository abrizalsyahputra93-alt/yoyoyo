// ============================================
// HOME.JS – Landing Page Logic
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  // Check existing session
  const session = loadWalletSession();
  if (session) {
    // Already logged in → redirect to dashboard
    window.location.href = 'dashboard/index.html';
    return;
  }

  // Connect button
  document.getElementById('connectBtn').addEventListener('click', openWalletModal);
});

function setAmt(v) {
  document.getElementById('homeAmount').value = v;
}

async function submitHomeDonation() {
  const username = (document.getElementById('homeStreamerInput')?.value || '').trim();
  const amount   = parseFloat(document.getElementById('homeAmount')?.value);
  const msg      = document.getElementById('homeMsg')?.value || '';
  const privacy  = document.getElementById('homePrivacy')?.checked ?? true;

  if (!username) { toast('Enter a streamer username', 'error'); return; }
  if (!amount || amount <= 0) { toast('Enter a valid amount', 'error'); return; }

  // Look up streamer
  const streamer = loadDonationLinkByUsername(username);
  if (!streamer) {
    toast(`Streamer "${username}" not found. Make sure they have set up their UmbraShield link.`, 'error');
    return;
  }

  if (amount < (streamer.minDonation || 0.01)) {
    toast(`Minimum donation for this streamer is ${streamer.minDonation} SOL`, 'error');
    return;
  }

  const session = loadWalletSession();
  if (!session) { toast('Connect your wallet first', 'error'); openWalletModal(); return; }
  Core.wallet = session;

  const provider = window.solana || window.phantom?.solana;
  if (!provider) { toast('Phantom wallet not found', 'error'); return; }

  showTxModal('Sending Donation');
  setTxStep(1);

  try {
    let sig;

    setTxStep(2);
    await delay(400);
    setTxStep(3);

    if (privacy) {
      // Try Umbra confidential transfer first
      const client = await initUmbraClient(provider, session.publicKey);
      if (client && UmbraSDK.getPublicBalanceToEncryptedBalanceDirectDepositorFunction) {
        try {
          // Register if needed
          const register = UmbraSDK.getUserRegistrationFunction({ client });
          await register({ confidential: true, anonymous: true });

          // Confidential donation
          const deposit = UmbraSDK.getPublicBalanceToEncryptedBalanceDirectDepositorFunction({ client });
          const result = await deposit(streamer.walletAddress, 'SOL', BigInt(Math.round(amount * 1e9)));
          sig = result?.signature || result;
        } catch (umbraErr) {
          console.warn('Umbra transfer failed, falling back to plain SOL:', umbraErr.message);
          // Fallback to real SOL transfer on devnet
          sig = await sendSolTransfer(provider, session.publicKey, streamer.walletAddress, amount);
        }
      } else {
        // Umbra SDK not fully functional in browser, use real SOL transfer
        sig = await sendSolTransfer(provider, session.publicKey, streamer.walletAddress, amount);
      }
    } else {
      // Plain SOL transfer (no privacy shield)
      sig = await sendSolTransfer(provider, session.publicKey, streamer.walletAddress, amount);
    }

    setTxStep(4);

    // Save record
    saveDonationRecord(streamer.walletAddress, {
      sig, amount, message: msg, privacy,
      from: session.publicKey,
      timestamp: new Date().toISOString()
    });

    showTxSuccess(sig, `${amount} SOL sent to ${streamer.displayName}!`);
  } catch (err) {
    console.error(err);
    showTxError(err.message);
  }
}

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }
